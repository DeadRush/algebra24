import Table from "./components/table";
import "./styles/style.scss";

const App = () => {
  return (
    <>
      <Table />
    </>
  );
};

export default App;
