export type CarType = {
  brand: string;
  model: string;
  year: number;
  imgUrl: string;
  diesel: boolean;
  id: string;
};
